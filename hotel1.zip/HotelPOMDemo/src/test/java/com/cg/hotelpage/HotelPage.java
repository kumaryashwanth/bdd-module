package com.cg.hotelpage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HotelPage {

	private WebDriver driver;
	
	@FindBy(how = How.XPATH,using = "/html/body/div/h2")
	@CacheLookup
	private WebElement heading;
	
	public String titlename() {
		return this.heading.getText();
	}
	
	@FindBy(how = How.ID,using = "txtFirstName")
	@CacheLookup
	private WebElement firstName;
	
	@FindBy(how = How.ID,using = "txtLastName")
	@CacheLookup
	private WebElement lastName;
	
	@FindBy(how = How.ID,using = "txtEmail")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how = How.ID,using = "txtPhone")
	@CacheLookup
	private WebElement mobileNo;
	
	@FindBy(how = How.XPATH,using = "/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	private WebElement address;
	
	@FindBy(how = How.NAME,using = "city")
	@CacheLookup
	private WebElement city;
	
	@FindBy(how = How.NAME,using = "state")
	@CacheLookup
	private WebElement state;
	
	@FindBy(how = How.NAME,using = "persons")
	@CacheLookup
	private WebElement noOfPeople;
	
	@FindBy(how = How.ID,using = "txtCardholderName")
	@CacheLookup
	private WebElement cardHolderName;
	
	@FindBy(how = How.ID,using = "txtDebit")
	@CacheLookup
	private WebElement debitCardNo;
	
	@FindBy(how = How.ID,using = "txtCvv")
	@CacheLookup
	private WebElement cvv;
	
	@FindBy(how = How.ID,using = "txtMonth")
	@CacheLookup
	private WebElement expirymnth;
	
	@FindBy(how = How.ID,using = "txtYear")
	@CacheLookup
	private WebElement expiryyr;
	
	@FindBy(how = How.ID,using = "btnPayment")
	private WebElement confirmbookingbtn;

	public HotelPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HotelPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getNoOfPeople() {
		return noOfPeople;
	}

	public void setNoOfPeople(String noOfPeople) {
		this.noOfPeople.sendKeys(noOfPeople);
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public WebElement getDebitCardNo() {
		return debitCardNo;
	}

	public void setDebitCardNo(String debitCardNo) {
		this.debitCardNo.sendKeys(debitCardNo);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getExpirymnth() {
		return expirymnth;
	}

	public void setExpirymnth(String expirymnth) {
		this.expirymnth.sendKeys(expirymnth);
	}

	public WebElement getExpiryyr() {
		return expiryyr;
	}

	public void setExpiryyr(String expiryyr) {
		this.expiryyr.sendKeys(expiryyr);
	}
	
	public void confirmbookingbtn() {
		confirmbookingbtn.click();
	}
	
	
	
	
}
