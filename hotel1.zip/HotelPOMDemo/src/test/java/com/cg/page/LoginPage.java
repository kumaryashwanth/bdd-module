package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {

	private WebDriver driver;

	@FindBy(how = How.XPATH, using = "//*[@id=\"mainCnt\"]/div/div[1]/h1")
	@CacheLookup
	private WebElement heading;

	public String titlename() {
		return this.heading.getText();
	}

	@FindBy(how = How.NAME, using = "userName")
	@CacheLookup
	private WebElement username;

	@FindBy(how = How.NAME, using = "userPwd")
	@CacheLookup
	private WebElement password;

	@FindBy(how = How.CLASS_NAME, using = "btn")
	@CacheLookup
	private WebElement loginbtn;

	@FindBy(how = How.ID, using = "userErrMsg")
	private WebElement userErrMsg;

	@FindBy(how = How.ID, using = "pwdErrMsg")
	private WebElement pwdErrMsg;

	public LoginPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void loginBtnClick() {
		loginbtn.click();
	}

	public String unameError() {
		return this.userErrMsg.getText();
	}

	public String pwdError() {
		return this.pwdErrMsg.getText();
	}
}
