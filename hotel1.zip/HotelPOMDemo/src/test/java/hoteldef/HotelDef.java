package hoteldef;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.hotelpage.HotelPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelDef {
	static WebDriver driver;
	HotelPage hotelPage;

	@Before
	public void start() {
		driver = BrowserFactory.startBrowser("chrome",
				"D:\\Users\\banuprr\\Selenium\\HotelPOMDemo\\src\\test\\java\\html\\hotelbooking.html");
	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Given("^user is in the hotel booking page$")
	public void user_is_in_the_hotel_booking_page() throws Throwable {
		hotelPage = PageFactory.initElements(driver, HotelPage.class);
	}

	@Then("^verify the heading of the page$")
	public void verify_the_heading_of_the_page() throws Throwable {
		assertEquals("Hotel Booking Form", hotelPage.titlename());
		if (hotelPage.titlename().equals("Hotel Booking Form")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^user enters valid credentials$")
	public void user_enters_valid_credentials() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();

	}

	@Then("^successfully booked and navigated to Payment Details page$")
	public void successfully_booked_and_navigated_to_Payment_Details_page() throws Throwable {
		driver.navigate().to("file:///D:/Users/banuprr/Selenium/HotelPOMDemo/src/test/java/html/success.html");
	}

	@When("^user leaves first name empty$")
	public void user_leaves_first_name_empty() throws Throwable {
		hotelPage.setFirstName("");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();

	}

	@Then("^display first name alert message$")
	public void display_first_name_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the First Name", msg);
		if (msg.equals("Please fill the First Name")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves last name empty$")
	public void user_leaves_last_name_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();
	}

	@Then("^display last name alert message$")
	public void display_last_name_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the Last Name", msg);
		if (msg.equals("Please fill the Last Name")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves email empty$")
	public void user_leaves_email_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();
	}

	@Then("^display email alert message$")
	public void display_email_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the Email", msg);
		if (msg.equals("Please fill the Email")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User enters the incorrect Email format$")
	public void user_enters_the_incorrect_Email_format(DataTable arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<String> emailList = arg1.asList(String.class);
		hotelPage.setFirstName("yuvanesh");
		hotelPage.setLastName("abinandha");
		for (String email : emailList) {
			hotelPage.getEmail().clear();
			hotelPage.setEmail(email);
			if(Pattern.matches("/[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$/", email)) {
				System.out.println("Valid Email Id: "+email);
			}
			else {
				System.out.println("Pattern not matching, Invalid email id ");
			}
		}
		hotelPage.setMobileNo("9876543210");
		hotelPage.setAddress("katpadi");
		hotelPage.setCity("Chennai");
		hotelPage.setState("Tamilnadu");
		hotelPage.setNoOfPeople("6");
		hotelPage.setCardHolderName("yuvanesh");
		hotelPage.setDebitCardNo("5491029152062255");
		hotelPage.setCvv("577");
		hotelPage.setExpirymnth("04");
		hotelPage.setExpiryyr("2024"); 
		
	}

	@When("^clicks Confirm Booking button$")
	public void clicks_Confirm_Booking_button() throws Throwable {
		hotelPage.confirmbookingbtn();
	}

	@Then("^Display Invalid Email Alert message$")
	public void display_Invalid_Email_Alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please enter valid Email Id.", msg);
		if (msg.equals("Please enter valid Email Id.")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves mobileNo empty$")
	public void user_leaves_mobileNo_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();
	}

	@Then("^display mobileNo alert message$")
	public void display_mobileNo_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the Mobile No.", msg);
		if (msg.equals("Please fill the Mobile No.")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}
	
	@When("^User enters the incorrect Contact Number format$")
	public void user_enters_the_incorrect_Contact_Number_format(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			hotelPage.setMobileNo(objlist.get(i));
			if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objlist.get(i))) {
				System.out.println("****** Matched valid phone no " + objlist.get(i) + "*****");
			} else {
				System.out.println("Pattern not matching, Invalid mobile no");
			}
		}
		hotelPage.confirmbookingbtn();
	}

	@Then("^Display Invalid Contact Number Alert message$")
	public void display_Invalid_Contact_Number_Alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		Thread.sleep(1000);
		String msg = alt.getText();
		assertEquals("Please enter valid Contact no.", msg);
		if (msg.equals("Please enter valid Contact no.")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}


	@When("^user enters no of guests (\\d+) and no of rooms (\\d+)$")
	public void user_enters_no_of_guests_and_no_of_rooms(int arg1, int arg2) throws Throwable {
		if (arg1 <= 3) {
			assertEquals(1, arg2);
			System.out.println("1 room allowed");
		} else if (arg1 <= 6) {
			assertEquals(2, arg2);
			System.out.println("2 room allowed");
		} else if (arg1 <= 9) {
			assertEquals(3, arg2);
			System.out.println("3 room allowed");
		}
	}

	@When("^User enters address details$")
	public void user_enters_address_details() throws Throwable {
		hotelPage.setAddress("Chennai");
		hotelPage.confirmbookingbtn();
	}

	@Then("^message displayed address details captured$")
	public void message_displayed_address_details_captured() throws Throwable {
		System.out.println("address details captured");
	}

	/*
	 * @When("^user enters incorrect contactNo format and clicks the confirm booking button$"
	 * ) public void
	 * user_enters_incorrect_contactNo_format_and_clicks_the_confirm_booking_button(
	 * DataTable arg1) throws Throwable { // Write code here that turns the phrase
	 * above into concrete actions // For automatic transformation, change DataTable
	 * to one of // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>. //
	 * E,K,V must be a scalar (String, Integer, Date, enum etc)
	 * hotelPage.setFirstName("banupriya"); hotelPage.setLastName("R");
	 * hotelPage.setEmail("banu@gmail.com"); hotelPage.setMobileNo("");
	 * hotelPage.setAddress("chennai"); hotelPage.setCity("chennai");
	 * hotelPage.setState("tamilnadu"); hotelPage.setNoOfPeople("2");
	 * hotelPage.setCardHolderName("banupriya");
	 * hotelPage.setDebitCardNo("1234123412341234"); hotelPage.setCvv("123");
	 * hotelPage.setExpirymnth("03"); hotelPage.setExpiryyr("2020");
	 * hotelPage.confirmbookingbtn(); List<String> objlist =
	 * arg1.asList(String.class); for (int i = 0; i < objlist.size(); i++) {
	 * 
	 * if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objlist.get(i))) {
	 * System.out.println("****** Matched valid phone no " + objlist.get(i) +
	 * "*****"); } else {
	 * System.out.println("Pattern not matching, Invalid mobile no"); } }
	 * hotelPage.confirmbookingbtn(); }
	 */

	/*
	 * @Then("^alert message please select the noOfpeople$") public void
	 * alert_message_please_select_the_noOfpeople() throws Throwable { Alert alt =
	 * driver.switchTo().alert(); driver.manage().timeouts().implicitlyWait(500,
	 * TimeUnit.SECONDS); String msg = alt.getText();
	 * assertEquals("Please fill the Number of people attending", msg); if
	 * (msg.equals("Please fill the Number of people attending")) {
	 * System.out.println("The text msg on alert box is " + msg); } else {
	 * System.out.println("The text msg on alert box is not correct"); }
	 * alt.accept(); }
	 */
	@When("^user doesn't select the city$")
	public void user_doesn_t_select_the_city() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();
	}

	@Then("^alert message please select the city$")
	public void alert_message_please_select_the_city() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please select city", msg);
		if (msg.equals("Please select city")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user doesn't select the state$")
	public void user_doesn_t_select_the_state() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();

	}

	@Then("^alert message please select the state$")
	public void alert_message_please_select_the_state() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please select state", msg);
		if (msg.equals("Please select state")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves cardHoldername empty$")
	public void user_leaves_cardHoldername_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();

	}

	@Then("^display cardHoldername alert message$")
	public void display_cardHoldername_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the Card holder name", msg);
		if (msg.equals("Please fill the Card holder name")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves debitCardNo empty$")
	public void user_leaves_debitCardNo_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();

	}

	@Then("^display debitCardNo alert message$")
	public void display_debitCardNo_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the Debit card Number", msg);
		if (msg.equals("Please fill the Debit card Number")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves cardExpiryMnth empty$")
	public void user_leaves_cardExpiryMnth_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("");
		hotelPage.setExpiryyr("2020");
		hotelPage.confirmbookingbtn();

	}

	@Then("^display cardExpiryMnth alert message$")
	public void display_cardExpiryMnth_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill expiration month", msg);
		if (msg.equals("Please fill expiration month")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves cardExpiryYear empty$")
	public void user_leaves_cardExpiryYear_empty() throws Throwable {
		hotelPage.setFirstName("banupriya");
		hotelPage.setLastName("R");
		hotelPage.setEmail("banu@gmail.com");
		hotelPage.setMobileNo("9003259660");
		hotelPage.setAddress("chennai");
		hotelPage.setCity("chennai");
		hotelPage.setState("tamilnadu");
		hotelPage.setNoOfPeople("2");
		hotelPage.setCardHolderName("banupriya");
		hotelPage.setDebitCardNo("1234123412341234");
		hotelPage.setCvv("123");
		hotelPage.setExpirymnth("03");
		hotelPage.setExpiryyr("");
		hotelPage.confirmbookingbtn();

	}

	@Then("^display cardExpiryYear alert message$")
	public void display_cardExpiryYear_alert_message() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please fill the expiration year", msg);
		if (msg.equals("Please fill the expiration year")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

}
