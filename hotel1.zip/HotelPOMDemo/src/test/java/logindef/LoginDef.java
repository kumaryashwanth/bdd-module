package logindef;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.LoginPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginDef {
	static WebDriver driver;
	LoginPage loginPage;

	@Before
	public void start() {
		driver = BrowserFactory.startBrowser("chrome",
				"file:///D:/Users/banuprr/Selenium/HotelPOMDemo/src/test/java/html/login.html");
	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Given("^user is in the login page$")
	public void user_is_in_the_login_page() throws Throwable {
		loginPage = PageFactory.initElements(driver, LoginPage.class);
	}
	
	
	@Then("^verify the heading of the page$")
	public void verify_the_heading_of_the_page() throws Throwable {
		assertEquals("Hotel Booking Application", loginPage.titlename());
		if (loginPage.titlename().equals("Hotel Booking Application")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^user enters valid credentials$")
	public void user_enters_valid_credentials() throws Throwable {
		loginPage.setUsername("capgemini");
		loginPage.setPassword("capg1234");
		loginPage.loginBtnClick();

	}

	@Then("^successfully booked and navigated to hotel booking page$")
	public void successfully_booked_and_navigated_to_hotel_booking_page() throws Throwable {
		driver.navigate().to("file:///D:/Users/banuprr/Selenium/HotelPOMDemo/src/test/java/html/hotelbooking.html");
	}

	@When("^user leaves username empty$")
	public void user_leaves_username_empty() throws Throwable {
		loginPage.setUsername("");
		loginPage.setPassword("capg1234");
		loginPage.loginBtnClick();

	}

	@Then("^display username error message$")
	public void display_username_error_message() throws Throwable {
		assertEquals("* Please enter userName.", loginPage.unameError());
		if (loginPage.unameError().equals("* Please enter userName.")) {
			System.out.println("The text msg on alert box is " + loginPage.unameError());
		} else {
			System.out.println("The text msg on alert box is not correct");
		}

	}

	@When("^user leaves password empty$")
	public void user_leaves_password_empty() throws Throwable {
		loginPage.setUsername("capgemini");
		loginPage.setPassword("");
		loginPage.loginBtnClick();
	}

	@Then("^display password error message$")
	public void display_password_error_message() throws Throwable {
		assertEquals("* Please enter password.", loginPage.pwdError());
		if (loginPage.pwdError().equals("* Please enter password.")) {
			System.out.println("The text msg on alert box is " + loginPage.pwdError());
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
	}

}
