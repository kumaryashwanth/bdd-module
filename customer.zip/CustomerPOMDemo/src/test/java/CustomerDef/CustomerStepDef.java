package CustomerDef;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.CustomerPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerStepDef {

	static WebDriver driver;
	CustomerPage cuspage;

	@Before
	public void start() {
		driver = BrowserFactory.startBrowser("chrome",
				"D:\\Users\\banuprr\\Selenium\\CustomerPOMDemo\\src\\test\\java\\html\\Customerorder.html");
	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Given("^Customer is on Welcome to Customerorder page$")
	public void customer_is_on_Welcome_to_Customerorder_page() throws Throwable {
		cuspage = PageFactory.initElements(driver, CustomerPage.class);
	}

	@Then("^Verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		assertEquals("Welcome", driver.getTitle());
		if (driver.getTitle().equals("Welcome")) {
			System.out.println("Title is matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^customer enters all valid inputs$")
	public void customer_enters_all_valid_inputs() throws Throwable {
		cuspage.setCusName("banupriya");
		cuspage.setAddress("chennai");
		cuspage.setContactNo("9003259660");
		cuspage.placeOrderBtn();

	}

	@Then("^It should display successful message on next page$")
	public void it_should_display_successful_message_on_next_page() throws Throwable {
		driver.navigate().to("about:blank");
	}

	@When("^Customer leaves Customer Name empty$")
	public void customer_leaves_Customer_Name_empty() throws Throwable {
		cuspage.setCusName("");
		cuspage.setAddress("chennai");
		cuspage.setContactNo("9003259660");
	}

	@When("^Clicks the Place Order button$")
	public void clicks_the_Place_Order_button() throws Throwable {
		cuspage.placeOrderBtn();
	}

	@Then("^Display name Alert msg$")
	public void display_name_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please Enter The Customer Name", msg);
		if (msg.equals("Please Enter The Customer Name")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^Customer leaves contact empty$")
	public void customer_leaves_contact_empty() throws Throwable {
		cuspage.setCusName("banupriya");
		cuspage.setAddress("chennai");
		cuspage.setContactNo("");
		
	}

	@Then("^display contact Alert msg$")
	public void display_contact_Alert_msg() throws Throwable {
		System.out.println("alert displayed");
	}

	@When("^Customer leaves address empty$")
	public void customer_leaves_address_empty() throws Throwable {
		cuspage.setCusName("banupriya");
		cuspage.setAddress("");
		cuspage.setContactNo("9003259660");
		
	}

	@Then("^display address Alert msg$")
	public void display_address_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please Enter Delivery Details", msg);
		if (msg.equals("Please Enter Delivery Details")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^customer enters Customer name \"([^\"]*)\" and address \"([^\"]*)\"$")
	public void customer_enters_Customer_name_and_address(String arg1, String arg2) throws Throwable {
		cuspage.setCusName("banupriya");
		cuspage.setAddress("chennai");
		
	}

	@Then("^Order should get placed successfully$")
	public void order_should_get_placed_successfully() throws Throwable {
		System.out.println("Placed order successfully");
		
		driver.navigate().to("file:///D:/Users/banuprr/Selenium/CustomerPOMDemo/src/test/java/html/success.html");
	}

	@When("^Customer enters incorrect mobileNo format and clicks the place order button$")
	public void customer_enters_incorrect_mobileNo_format_and_clicks_the_place_order_button(DataTable arg1)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)
		cuspage.setCusName("banupriya");
		cuspage.setAddress("chennai");
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {

			if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objlist.get(i))) {
				System.out.println("****** Matched valid phone no " + objlist.get(i) + "*****");
			} else {
				System.out.println("Pattern not matching, Invalid mobile no");
			}
		}
		cuspage.placeOrderBtn();
		driver.navigate().to("file:///D:/Users/banuprr/Selenium/CustomerPOMDemo/src/test/java/html/Help.html");
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {		
		System.out.println("Alert message displayed");
		
	}

	@When("^customer click on hyperlink$")
	public void customer_click_on_hyperlink() throws Throwable {
		cuspage.helpclick();
	}

	@Then("^customer navigate to help page$")
	public void customer_navigate_to_help_page() throws Throwable {
		driver.navigate().to("file:///D:/Users/banuprr/Selenium/CustomerPOMDemo/src/test/java/html/Help.html");
	}

}
